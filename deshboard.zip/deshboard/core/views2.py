from django.shortcuts import render



def temp(request,group_name):
    return render(request,"ARVR/temp.html",{"groupname":group_name})

def noise(request,group_name):
    return render(request,"ARVR/noise.html",{"groupname":group_name})

def vib_x(request,group_name):
    return render(request,"ARVR/vib_x.html",{"groupname":group_name})

def vib_y(request,group_name):
    return render(request,"ARVR/vib_y.html",{"groupname":group_name})

def vib_z(request,group_name):
    return render(request,"ARVR/vib_z.html",{"groupname":group_name})

def press(request,group_name):
    return render(request,"ARVR/press.html",{"groupname":group_name})




def futuretemp(request,group_name):
    return render(request,"ARVR/temp.html",{"groupname":group_name})

def futurenoise(request,group_name):
    return render(request,"ARVR/noise.html",{"groupname":group_name})

def futurevib_x(request,group_name):
    return render(request,"ARVR/vib_x.html",{"groupname":group_name})

def futurevib_y(request,group_name):
    return render(request,"ARVR/vib_y.html",{"groupname":group_name})

def futurevib_z(request,group_name):
    return render(request,"ARVR/vib_z.html",{"groupname":group_name})

def futurepress(request,group_name):
    return render(request,"ARVR/press.html",{"groupname":group_name})