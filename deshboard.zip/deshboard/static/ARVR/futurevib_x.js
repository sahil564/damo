const groupname=JSON.parse(document.getElementById("group-name").textContent)
const pred=JSON.parse(document.getElementById("pred").textContent)
const low=JSON.parse(document.getElementById("low").textContent)
const upp=JSON.parse(document.getElementById("upp").textContent)
const predn=JSON.parse(document.getElementById("predn").textContent)
const lown=JSON.parse(document.getElementById("lown").textContent)
const uppn=JSON.parse(document.getElementById("uppn").textContent)
const predx=JSON.parse(document.getElementById("predx").textContent)
const lowx=JSON.parse(document.getElementById("lowx").textContent)
const uppx=JSON.parse(document.getElementById("uppx").textContent)
const predy=JSON.parse(document.getElementById("predy").textContent)
const lowy=JSON.parse(document.getElementById("lowy").textContent)
const uppy=JSON.parse(document.getElementById("uppy").textContent)
const predz=JSON.parse(document.getElementById("predz").textContent)
const lowz=JSON.parse(document.getElementById("lowz").textContent)
const uppz=JSON.parse(document.getElementById("uppz").textContent)
const predp=JSON.parse(document.getElementById("predp").textContent)
const lowp=JSON.parse(document.getElementById("lowp").textContent)
const uppp=JSON.parse(document.getElementById("uppp").textContent)
console.log("group Name....",groupname)
console.log("data....",pred)
















const ctx3 = document.getElementById('myChart3').getContext('2d');

var graphData3 = {
    type: 'line',
    data: {
        labels: predx,
        datasets: [{
            label: 'upper value',
            data: uppx,
            options: {

                responsive: false
            },
 
            backgroundColor: [
                'rgba(255,248,220, 0.2)',
            ],
            borderColor: [
                'rgba(0, 0, 255, 0)',
      
            ],
           
            tension:0.4,
            fill:1
        },
        {
            label: 'predicted value',
            data:predx,
            options: {

                responsive: false
            },
 
            backgroundColor: [
                'rgba(255, 191, 0, 1)',

            ],
            borderColor: [
                'rgba(255, 191, 0, 1)',
      
            ],
            tension:0.4,
            },
            {
                label: 'actual values',
                data:[],
                options: {
    
                    responsive: false
                },
     
                backgroundColor: [
                    'rgba(0, 255, 0, 1)',
    
                ],
                borderColor: [
                    'rgba(0, 255, 0, 1)',
          
                ],
                tension:0.4,
                },
        {
            label: 'lower value',
            data: lowx,
            options: {

                responsive: false
            },
 
            backgroundColor: [
                'rgba(255,248,220, 0.2)',
            ],
            borderColor: [
                'rgba(0, 0, 255, 0)',
      
            ],
           
            tension:0.4,
            fill:1
        },
    ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        },
        plugins: {
            zoom: {
                pan: {
                  enabled:true,
                },
                zoom: {
                 wheel:{
                    enabled: true,
                    //speed:0.1, speedup zooming or zoomout
                  }

                    
               }
            }
        }
    }
}
var myChart3 = new Chart(ctx3, graphData3 );  

var ws = new WebSocket('ws://'+window.location.host + '/ws/jwc/' + groupname + '/')
ws.onmessage = function(e){
    var djangoData=JSON.parse(e.data);
    // console.log(djangoData);
    // console.log("message recieved from server.....",e)
    const data = JSON.parse(e.data)
    var djangoData=JSON.parse(e.data);
    // console.log("this is ",djangoData);
    const myarray=djangoData.split(",")
    // console.log(myarray[1])
    // console.log(myarray[2])
    var v=myarray[2]
    // console.log(myarray[3])
    // var s=" "
    // var newLevel3=graphData3.data.labels
    // if (myarray[5]) {

    // var timestamp = myarray[5];
    // var date = new Date(timestamp*1000);
    // var s =new Date(date).toLocaleTimeString(undefined,{timeZone:"Asia/Kolkata"})
    // console.log(s)


    //     newLevel3.shift();
    //     newLevel3.push(s)
        
    //   } else {
    //     newLevel3.shift();
    //     newLevel3.push(s)
    //     //  block of code to be executed if the condition is false
    //   }
 
    var newGraphData3 = graphData3.data.datasets[2].data;
    // newGraphData3.shift();
    newGraphData3.push(v);
    graphData3.data.datasets[2].data = newGraphData3;
    myChart3.update();

    
}
function ZoomChartInx(){
    myChart3.zoom(1.1)
 
}


function ZoomChartOutx(){
    myChart3.zoom(0.1)
    // myChart.resetZoom();
    // alert("Hello Zoomout"); 
}


function resetZoomChartx(){
    myChart3.resetZoom();
}
