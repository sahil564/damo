"""Version information"""

__version__ = "2.5.2"
__version_info__ = (2, 5, 2)
