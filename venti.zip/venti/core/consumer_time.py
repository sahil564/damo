
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync,sync_to_async
import json
from .models import *
import asyncio
from core.models import *
import time
from http import client
import paho.mqtt.client as paho
import sys
from channels.layers import get_channel_layer
from base64 import decode
# import pymysql
import time
from threading import Thread
import pickle
from threading import Thread







pickled_model1 = pickle.load(open('fire-connect_version1.pkl', 'rb'))
# Create your views here.


async def home1(group,msg):
    channel_layer=get_channel_layer()
    await (channel_layer.group_send)(group,{'type':"send_order",'value':json.dumps(msg)})









class TimeConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        print("Websocket connect....")
        print("channel Layer",self.channel_layer)
        print("channel Name",self.channel_name)
        self.group_name = self.scope['url_route']['kwargs']['groupname']
        print("group Name:",self.group_name)
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        await self.accept()
        # self.group_name='order_data'
        # await self.channel_layer.group_add(
        #     self.group_name,
        #     self.channel_name
        # )

        # await self.accept()

    async def disconnect(self,close_code):
        pass

    async def receive(self,text_data):
        print (text_data)
        await self.channel_layer.group_send(
            self.group_name,
            {
                'type':'time_model',
                'value':text_data,
            }
        )

    async def time_model(self,event):
        # print ("this is event",event['value'])
        await self.send(event['value'])









        


