from django.shortcuts import render
from random import randint
# Create your views here.
from multiprocessing import context
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect 
from datetime import datetime
from django.contrib import messages
from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from channels.layers import get_channel_layer
# from core.models import TVS #add this
# Create your views here.
from .models import Machine as ma
from .forms import *
from .models import permission as per
# from .filters import OrderFilter

from channels.generic.websocket import AsyncWebsocketConsumer
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync,sync_to_async
import json
from .models import *
import asyncio
from core.models import *
import time
from http import client
import paho.mqtt.client as paho
import sys
from channels.layers import get_channel_layer
from base64 import decode
# import pymysql
import time
from threading import Thread
import pickle
from threading import Thread


from email import message
from django.shortcuts import render, redirect
from pyexpat.errors import messages
from wsgiref.util import request_uri
from django.shortcuts import render
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate
from django.contrib import messages
import pickle

import sqlite3
connection = sqlite3.connect("gfg.db",check_same_thread=False)
 
# cursor
crs = connection.cursor()

#model = pickle.load(open('/home/user/Desktop/final-fire-connect/DEC_23/fireconnect (2)/core/fire-connect_version1.pkl', 'rb'))

# res=model.predict([[a]])


# Create your views here.
def base(request):
    return render(request,'front.html',context={"text":"hello world"})



# Create your views here.
def index(request):
    
 
    return render(request, 'index.html')
    # return HttpResponse("this is homepage")

def about(request):
    return render(request, 'header.html') 

def services(request):
    return render(request, 'desborad.html')





def levelone(user,machine):
    print("Level one alert has been occured",user,machine)
    



def leveltwo(user,machine):
    print("email has been sent!!!!")



def levelthird(user,machine):
    print("email has been sent!!!!")




def levelforth(user,machine):
    print("email has been sent!!!!")





runningmachine=[]


damo=[]

def machineruning(i):
    
    if i not in runningmachine:
        runningmachine.append(i)
    print("runing",runningmachine,len(runningmachine))
    damo.append(1)
    print("this",len(damo))
    
    if len(damo)>=50:
        print("else is called")
        runningmachine.clear()
        damo.clear()
        
    










threads = []
stop_m=[]
all_machine=[]
l=[]

# async def mlmodel(group,msg):
    
#     print("ml model has been called")
#     channel_layer=get_channel_layer()
#     await (channel_layer.group_send)(group,{'type':"send_pred",'value':json.dumps(msg)})
    









async def home1(group,msg):
    # await time.sleep(0.1)
    # time.sleep(1)
    # print("this is async",msg)
    # print("this is async",type(msg))
    # a=','.join(msg.split(',')[:-1])
    # temlist= a.split(',')
    # print(temlist)
    
    
    # crs.execute("""INSERT INTO {}(temp,Noise,vibrations_x,vibrations_y,vibrations_z,humidity,pressure,lpg,co,smoke,time) VALUES ("%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s")""".format(group) % (temlist[0],temlist[1],temlist[2],temlist[3],temlist[4],temlist[5],temlist[6],temlist[7],temlist[8],temlist[9],temlist[10]))        
    # connection.commit() 
    
    try:
        channel_layer=get_channel_layer()
        await (channel_layer.group_send)(group,{'type':"send_order",'value':json.dumps(msg)})
    except:
        print("this is out side thread")
    # await time.sleep(.1)

a=[]


data=[]

future=['1','2','3']


def data_recieve(group,msg,model):
    
    # print("al model name",model)
    path=Mlmodel.objects.get(name=model)
    path=path.file.path
    # print("al model path",path)
    
    model = pickle.load(open(path,'rb'))
    
    a=','.join(msg.split(',')[:-1])
    temlist= a.split(',')
    print(len(temlist))
    biglist=[int(float(temlist[0])),int(float(temlist[1])),int(float(temlist[2])),int(float(temlist[3])),int(float(temlist[4]))]
    
    biglistlast=[int(float(temlist[0])),int(float(temlist[1])),int(float(temlist[2])),int(float(temlist[3])),int(float(temlist[4])),int(float(temlist[5])),int(float(temlist[6])),int(float(temlist[7])),int(float(temlist[8])),int(float(temlist[9]))]
    # print("this is list for ai model",biglist)  
    # print("this is whole meass",biglist,biglistlast)
    
    
  
    
    res=model.predict([biglist])[0]
    #res=temlist[10]
    # res=temlist[1]
    print(res)
    print(len(biglist))
    
    # if 5==len(biglist):
    #     res=model.predict([biglist]) 
    #     print(res[0])
    # else:
    #     print("ai model is not working because sensor is not working properly")
        
    
    
    
    
    
    # this code for alerts or we can say that sending email to user
    
    # if len(biglist)<5:
    #     print("This is level I alert Reason all sensor are not working!!!")
        
    # elif len(biglist)==0:
    #     print("This is level II alert Reason device is off or device is not connecting to internet!!!")
        
    # elif str(res[0])!='normal':
    #     print("This is level III alert Reason anomaly has been detected")
        
    # elif len(future)!=0:
    #     print('This is level IV alert Reason Future Failure detected)
        
    
    data.append(int(float(temlist[0])))
       
    # print(type(msg))
   
    # a=','.join(msg.split(',')[:-1])
    # temlist= a.split(',')
    # print(temlist)
    # print(temlist[0])
    # print(temlist[1])
    # print(temlist[2])
    # print(temlist[3])
    # print(temlist[4])
    # biglist=[int(temlist[0]),int(temlist[1]),int(temlist[2]),int(temlist[3]),int(temlist[4])]
    # print("this is list for ai model",biglist)
    # # print(type([[a]]))
    # res=model.predict([biglist])
    # print("this is model result",res)
    # print(a)
    # asyncio.run(mlmodel(group,"normal"))
    
    
    
    
    
    
    
    if str(res)=="No_Load":
        res1="ON"
        if len(l)>=5:
            msg=msg+","+str(res1)+","+str(len(data))+","+str(len(data)*32)#+","+str(int(float(temlist[6])))+","+str(int(float(temlist[7])))+","+str(int(float(temlist[8])))+","+str(int(float(temlist[9])))+","+str(int(float(temlist[10])))
            asyncio.run(home1(group,msg))
            l.clear()
            # print("if function has been called",msg)
        else:
            a=a+",,"+str(res1)+","+str(len(data))+","+str(len(data)*32)#+","+str(int(float(temlist[6])))+","+str(int(float(temlist[7])))+","+str(int(float(temlist[8])))+","+str(int(float(temlist[9])))+","+str(int(float(temlist[10])))
            asyncio.run(home1(group,a))
            l.append(msg)
            print(len(l))
            print("else function has been called",a)
        
   
    if str(res)=="bearing fault":
        res1="OFF"
        if len(l)>=5:
            msg=msg+","+str(res1)+","+str(len(data))+","+str(len(data)*32)#+","+str(int(float(temlist[6])))+","+str(int(float(temlist[7])))+","+str(int(float(temlist[8])))+","+str(int(float(temlist[9])))+","+str(int(float(temlist[10])))
            asyncio.run(home1(group,msg))
            l.clear()
            # print("if function has been called",msg)
        else:
            a=a+",,"+str(res1)+","+str(len(data))+","+str(len(data)*32)#+","+str(int(float(temlist[6])))+","+str(int(float(temlist[7])))+","+str(int(float(temlist[8])))+","+str(int(float(temlist[9])))+","+str(int(float(temlist[10])))
            asyncio.run(home1(group,a))
            l.append(msg)
            print(len(l))
            print("else function has been called",a)
          
   
   
   
   
        
    # asyncio.run(home1(group,a))   
    # print(group)
    # print(msg)
    # try:
    #     # asyncio.get_event_loop().run_until_complete(home1(group,msg))
    #     # asyncio.run(home1(group,msg))
    #     # trio.run(home1(group,msg))
    #     # print("function has been called")
    # except RuntimeError:
        
    #     # asyncio.get_event_loop().run_until_complete(home1(group,msg))
    #     # asyncio.run(home1(group,msg))
    #     print("execption solved")



def disp(i,model):
    
    #important
    
    connection = sqlite3.connect("gfg.db",check_same_thread=False)
    crs = connection.cursor()    
   
   
   
   
   
    # print(threads)
    # print("al model name",model)
    # path=Mlmodel.objects.get(name=model)
    # path=path.file.path
    # print("al model path",path)
    
    # model = pickle.load(open(path,'rb'))
    def onMessage(clinet,userdata,msg):
        print(threads)
        
        topic=msg.topic
        machineruning(topic)
        # print("size",machineruning)
            
        message=msg.payload.decode()
        if len(message)==0:
            print(len(message))
        # print(message)
        # print(topic,msg,model)

        msg1=msg.payload.decode()
        a=','.join(msg1.split(','))
        temlist= a.split(',')
        biglist=[temlist[0],temlist[1],temlist[2],temlist[3],temlist[4]]
        print(biglist)
        
        
        
        
        # table="""CREATE TABLE {} (temp VARCHAR(21),Noise VARCHAR(30),vibrations_x VARCHAR(30),vibrations_y VARCHAR(30),vibrations_z VARCHAR(30),humidity VARCHAR(30),pressure VARCHAR(30),lpg VARCHAR(30),co VARCHAR(30),smoke VARCHAR(30),time VARCHAR(30));""".format(topic)
        
        # try:
        #     # crs.execute(table)
        #     print("this is try block")
        #     crs.execute("SELECT * from {} order by temp desc limit 5".format(topic))
        #     r=crs.fetchall()    
        #     print(r)
        #     print(type(r))
        # except:
        #     crs.execute(table)
        #     print("table is already created")
        
        
      
      #savedataintodatabasecode
      
        
        crs.execute("""INSERT INTO {}(temp,Noise,vibrations_x,vibrations_y,vibrations_z,humidity,pressure,lpg,co,smoke,time) VALUES ("%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s")""".format(topic) % (temlist[0],temlist[1],temlist[2],temlist[3],temlist[4],temlist[5],temlist[6],temlist[7],temlist[8],temlist[9],temlist[10]))        
        connection.commit() 
       
       
       
       
       
       
        # crs.close()   
        # connection.close()
        # msg1=msg.payload.decode()
        # a=','.join(msg1.split(',')[:-1])
        # temlist= a.split(',')
        # biglist=[int(temlist[0]),int(temlist[1]),int(temlist[2]),int(temlist[3]),int(temlist[4])]
        # print("this is list for ai model",biglist)  
        # res=model.predict([biglist])  
        # print(res)    
            # print(threads)
            # print(msg.topic+": "+ msg.payload.decode())
            # print(type(msg.payload.decode()))
         
         
        try:
            data_recieve(topic,message,model)
        except:
            print("error occured in machine name", topic)
            # levelone()
            
            try:
                # a=','.join(message.split(','))
                temlist= message.split(',')
                print(temlist[1])
                # int(float(temlist[0]))
                try:
                    int(float(temlist[0]))
                except:
                    print("temparature sensor not working")
                    levelone()
                try:
                    int(float(temlist[1]))
                except:
                    
                    print("noise sensor not working")
                    levelone("TVS","CRM1")
                try:
                    int(float(temlist[2]))
                except:
                    
                    print("x_axis sensor not working")
                    levelone()
                try:
                    int(float(temlist[3]))
                except:
                    
                    print("y_axis sensor not working")
                    levelone()
                try:
                    int(float(temlist[4]))
                except:
                    
                    print("z_axis sensor not working")    
                    levelone()    
            
                try:
                    int(float(temlist[5]))
                except:
                   
                    print(" pressure sensor not working") 
                    levelone()
            
               
        # print(a)
        # b=','.join(msg.split(',')[:-1])
        # print(b)
        # chunks = str.split(',')
       
        
            except:
                print("sensor")


            
        

        #     # try:
        
            
            # except:
            #     print("Error: Denominator cannot be 0.")

            # prediction(a,s)
            # if a=='a3':
            #     sahil.append(s)
            # print(sahil)
            # print(pickled_model.predict([s]))

    client=paho.Client()
    client.on_message=onMessage

    if client.connect("18.188.62.3",1883,60)!=0:
        print("could not connect to MQTT broker!")
        sys.exit(-1)
    client.subscribe(i)

    try:
        print("press CTRL+C to exit....")
        client.loop_forever()

    except:
        print("Disconnecting from broker...")
        client.disconnect()
        time.sleep(1)

# Start all threads. 
# threads = []
# stop_m=[]
# all_machine=[]






# stop_machine=Stop_machine.objects.all()
# for name in stop_machine:
#     stop_m.append(name.machine)
 
all_ai_model=[]
    
student_list = Machine.objects.all()
for student in student_list:
    all_machine.append(student.username)
    all_ai_model.append(student.aimodel)
 
 
    
 
for n,model in zip(all_machine,all_ai_model):
    t = Thread(target=disp, args=(n,model))
    print("thred",n,model)
    t.start()
    threads.append(t)   

# while True:
#     print("all runing machine:",all_machine)
#     print("all stoping machine machine:",stop_m)    
#     print("number of thread runing:",threads)
#     for n in all_machine:
#         t = Thread(target=disp, args=(n,))
#         t.start()
#         threads.append(t)
#         time.sleep(5)
        
#     time.sleep(5)
    
    
    
print("all runing machine:",all_machine)
print("all stoping machine machine:",stop_m)    
print("number of thread runing:",threads)











def services1(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    all_ma=user.machine_set.all()
    fault=user.fault_occur_set.all()
    fault_count=user.fault_occur_set.count()
    fault_N=user.email_user_set.count()
    fault_a=user.fault_future_set.count()
    fault_b=user.fault_occur_set.count()
    a=user.mlmodel_set.count()
    b=user.time_model_set.count()
    
    total=a+b

    
    print("this is fault occured",fault)
    all_ma_count=user.machine_set.count()
    print("all machine is number",all_ma_count)
    machine_name=[]
    for i in all_ma:
        # print("machine name",i.machine_ID)
        machine_name.append(i.username)
    all_user=User.objects.all()
    print("current user",user)
    print("all user",all_user)
    print("all machines",all_ma)
    group_name="CITRIOT"
    conext={'machine':all_ma,'user':user,'n_m':all_ma_count,'fault':fault_a+fault_b,'N_sensor':all_ma_count*5,'N_email':fault_N,"total_ai_model":total,"groupname":group_name,"machine_name":machine_name}
    return render(request,'newdes.html',conext)
    
 
 
 
 
 
 
 





 
    
c=[]
for i in range(2000):
    c.append(randint(200,300))
# def machine(request):

def machine(request,group_name):
    print("this is machine name",group_name,len(c))
    group="second"
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    press=[]
    for i in range(len(r)):
        print(i)
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        press.append(r[i][5])
        
    print(noise)

    return render(request, 'machine.html',{"groupname":group_name,"fft":c,"temp":tep,"noise":noise,"x":x,"y":y,"z":z,"press":press})
 















def header(request):
    return render(request, 'Mheader.html')


def login(request):
    
    return render(request,"login1.html")



def log(request):
    return render(request,"log.html")



def home(request):
    return render(request,"home.html")


def register(request):
    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST["last_name"]
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                messages.info(request,"username is already exits")
                return redirect(register)
            else:
                user=User.objects.create(username=username,password=password,email=email,first_name=first_name,last_name=last_name)
                user.set_password(password)
                user1=newuser(username=username)
                user1.save()
                user.save()
                context={'orgnization':username,
                         "username":first_name}
                return render(request,'login.html',context)
    else:
        print("this is not post request")
        return render(request,"register.html")



# def login_user(request):
#     if request.method=="POST":
#         username=request.POST['username']
#         password=request.POST['password']
#         user=auth.authenticate(username=username,password=password)
#         if user is not None:
#             auth.login(request,user)
#             return redirect("services")

#         else:
#             messages.info(request,'Ivalid Username or Password')
#             return redirect("login_user")

#     else:
#         return render(request,'login.html')

# def login_user(request):
# 	if request.method == "POST":
# 		form = AuthenticationForm(request, data=request.POST)
# 		if form.is_valid():
# 			username = form.cleaned_data.get('username')
# 			password = form.cleaned_data.get('password')
# 			user = authenticate(username=username, password=password)
#             if user is not None:
#                 auth.login(request,user)
#                 return redirect("services")

#             else:
#                 messages.info(request,'Ivalid Username or Password')
#                 return redirect("login_user")

# 		else:
# 			messages.error(request,"Invalid username or password.")
# 	form = AuthenticationForm()
# 	return render(request=request, template_name="login.html")

def login_user(request):
    if request.method=="POST":
        form = AuthenticationForm(request,data=request.POST)
        if form.is_valid():
            username=request.POST['username']
            password=request.POST['password']
            print("username",username)
            user=authenticate(username=username,password=password)
            user1=per.objects.filter(username=username)
            user2=newuser.objects.filter(username=username)
            print("loginusername",user)
            print("per",user1.count())
            print("type",type(user1))
            if user is not None:
                
                if user2.count()==1:
                    messages.info(request,"User don't have login permission please contact to technical team")
                
                elif user1.count()==1:
                    messages.info(request,"User don't have login permission please contact to technical team")
                else:
                    auth.login(request,user)
                    context={'orgnization':password,"username":username,}
                    return redirect(services1)
                # return render(request,'newdes.html')
                
            else:
                messages.info(request,"Invalid Username or password")

        else:
            messages.error(request,"Invalid username or password.")


    form=AuthenticationForm
    return render(request=request,template_name="login.html")




def logout_user(request):
    auth.logout(request)
    return redirect("home1")

# from io import BytesIO
# import base64
# import matplotlib.pyplot as plt
# import numpy as np
# import matplotlib.pyplot as plt
# import numpy as np

def test(request): 
#     # Define X and Y variable data
#     x = np.array([1, 2, 3, 4])
#     y = x*2
#     plt.plot(x, y)
#     plt.xlabel("X-axis")  # add X-axis label
#     plt.ylabel("Y-axis")  # add Y-axis label
#     plt.title("Any suitable title")  # add tit

#     plt.tight_layout()

#     buffer = BytesIO()
#     plt.savefig(buffer, format='png')
#     buffer.seek(0)
#     image_png = buffer.getvalue()
#     buffer.close()

#     graphic = base64.b64encode(image_png)
#     graphic = graphic.decode('utf-8')

    return render(request, 'index111.html',)









def new_machine(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    aimodel=user.mlmodel_set.all()
    total=user.mlmodel_set.count()
    print("name of al model",aimodel)
    print("number of al model",total)
    
    
    if request.POST:
        form = ma(request.POST or None)
        username=request.POST['username']
        # email=request.POST["email"]
        machine_ID=request.POST["machine_ID"]
        machine_IDC=request.POST["machine_IDC"]
        aimodel=request.POST["aimodel"]
        print("this is ai model",aimodel)
        number=request.POST["number"]
        current_user=request.user
        id=current_user.id
        cust_id=User.objects.get(id=id)     
        user=ma(customer=cust_id,username=username,machine_ID=machine_ID,machine_IDC=machine_IDC,number=number,aimodel=aimodel)
        
        path=Mlmodel.objects.get(name=aimodel)
        # path=path.file.path
        print("path of ai model ",path)
        if ma.objects.filter(machine_ID = machine_ID).exists():
            print("already exists")
        else:
            user.save()
            
            table="""CREATE TABLE {} (temp VARCHAR(21),Noise VARCHAR(30),vibrations_x VARCHAR(30),vibrations_y VARCHAR(30),vibrations_z VARCHAR(30),humidity VARCHAR(30),pressure VARCHAR(30),lpg VARCHAR(30),co VARCHAR(30),smoke VARCHAR(30),time VARCHAR(30));""".format(username)
            crs.execute(table)
            
            t = Thread(target=disp, args=(username,path))
            print("thread has been created",username)
            t.start()
            threads.append(t)
        return redirect(services1) 
    #   
    # user.set_password(machine_ID)
    #             user.save()
    #             return redirect(newmachine)       
        # form=TVS(request.POST)
        # if form.is_valid():
        #     form.save()
        #     return redirect(machine)
            
    #     username=request.POST['username']
    #     password=request.POST["password"]
    #     email=request.POST["email"]
    #     machine_ID=request.POST["machine_ID"]
    #     machine_IDC=request.POST["machine_IDC"]
    #     sensor=request.POST["sensor"]
    #     sensorname=request.POST["sensorname"]
    #     phone=request.POST["phone"]
        
    #     if machine_ID==machine_IDC:
    #         if Machines.data(machine_ID!=machine_IDC):
    #             messages.info(request,"Machine is already exits")
    #             return redirect('machine')
    #         else:
    #             user=Machines.objects.create(username=username,password=password,email=email,machine_ID=machine_ID,machine_IDC=machine_IDC,sensor=sensor,sensorname=sensorname,phone=phone)
    #             user.set_password(machine_ID)
    #             user.save()
    #             return redirect(newmachine)
    else:
        print("this is not post request")
     
        return render(request,"create_new_m.html",{"aimodel":aimodel,"total":total})

































































# def registerPage(request):
# 	if request.user.is_authenticated:
# 		return redirect('register')
# 	else:
# 		form = CreateUserForm()
# 		if request.method == 'POST':
# 			form = CreateUserForm(request.POST)
# 			if form.is_valid():
# 				form.save()
# 				user = form.cleaned_data.get('username')
# 				messages.success(request, 'Account was created for ' + user)

# 				return redirect('login')
			

# 		context = {'form':form}
# 		return render(request, 'register.html', context)

# def loginPage(request):
# 	if request.user.is_authenticated:
# 		return redirect('register')
# 	else:
# 		if request.method == 'POST':
# 			username = request.POST.get('username')
# 			password =request.POST.get('password')

# 			user = authenticate(request, username=username, password=password)

# 			if user is not None:
# 				login(request, user)
# 				return redirect('home1')
# 			else:
# 				messages.info(request, 'Username OR password is incorrect')

# 		context = {}
# 		return render(request, 'login.html', context)


# def logoutUser(request):
# 	logout(request)
# 	return redirect('register')

