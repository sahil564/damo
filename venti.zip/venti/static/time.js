// var today = new Date();
// var day = today.getDay();
// var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
// var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
// var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
// var dateTime = date+' '+time;
 
// document.getElementById("displayDateTime").innerHTML = dateTime
// document.getElementById("displayDateTime1").innerHTML = dateTime



function timeCount() {
    var today = new Date();

    var day = today.getDate();
    var month = today.getMonth()+1;
    var year = today.getFullYear();

    var hour = today.getHours();
    if(hour<10)hour = "0"+hour;

    var minute = today.getMinutes();
    if(minute<10)minute = "0"+minute;

    var second = today.getSeconds();
    if(second<10)second = "0"+second;

    document.getElementById("clock").innerHTML = 
    day+"/"+month+"/"+year+" |"+000+":"+000+":"+000;

    setTimeout("timeCount()", 1000);
}
setTimeout("timeCount()", 1000);


function timeCount1() {
    var today = new Date();

    var day = today.getDate();
    var month = today.getMonth()+1;
    var year = today.getFullYear();

    var hour = today.getHours();
    if(hour<10)hour = "0"+hour;

    var minute = today.getMinutes();
    if(minute<10)minute = "0"+minute;

    var second = today.getSeconds();
    if(second<10)second = "0"+second;

    document.getElementById("clock1").innerHTML = 
    day+"/"+month+"/"+year+" |"+00+":"+minute+":"+second;

    setTimeout("timeCount1()", 1000);
}
setTimeout("timeCount1()", 1000);