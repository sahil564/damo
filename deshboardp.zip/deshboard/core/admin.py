from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(Machine)
admin.site.register(time_model)
# from .forms import *

admin.site.register(Mlmodel)

admin.site.register(Fault_occur)

admin.site.register(Fault_future)
admin.site.register(Email_user)