from django.contrib import admin
from .models import *


# Register your models here.


class PackageAdminView(admin.ModelAdmin):
    list_display = [
        'name',
        'image',
        'essential',
        'actual_price',
        'discounted_price',
        'ratings',
        'star_rating'
    ]


class EssentialAdminView(admin.ModelAdmin):
    list_display = [
        'name',
        'image'
    ]


class PackageHighlightAdminView(admin.ModelAdmin):
    list_display = [
        'package',
        'name',
        'image',
    ]


class ProcedureAdminView(admin.ModelAdmin):
    list_display = [
        'package',
        'image',
        'title',
        'description'
    ]


admin.site.register(Package, PackageAdminView)
admin.site.register(Essential, EssentialAdminView)
admin.site.register(PackageHighlight, PackageHighlightAdminView)
admin.site.register(Procedure, ProcedureAdminView)
