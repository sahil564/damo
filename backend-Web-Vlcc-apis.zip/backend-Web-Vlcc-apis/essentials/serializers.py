import math

from .models import *
from rest_framework import serializers


class PackageHighlightSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageHighlight
        fields = '__all__'


class ProcedureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Procedure
        fields = '__all__'


class EssentialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Essential
        fields = '__all__'


class PackageSerializer(serializers.ModelSerializer):
    procedures = ProcedureSerializer(many=True, read_only=True)
    package_highlights = PackageHighlightSerializer(many=True, read_only=True)
    discount = serializers.SerializerMethodField()

    @staticmethod
    def get_discount(obj):
        return math.ceil(((obj.actual_price - obj.discounted_price) / obj.actual_price) * 100)

    class Meta:
        model = Package
        fields = '__all__'


class EssentialPackageSerializer(serializers.ModelSerializer):
    packages = PackageSerializer(many=True, read_only=True)

    class Meta:
        model = Essential
        fields = ['id','name','image','packages']
