from django.db import models


# Create your models here.


class Essential(models.Model):
    name = models.CharField(max_length=250, help_text='Enter the name of the essential')
    image = models.ImageField(upload_to='essential_image/', help_text='Please enter the image of the essential')

    def __str__(self):
        return self.name


class   Package(models.Model):
    essential = models.ForeignKey(Essential, related_name='packages', on_delete=models.CASCADE)
    name = models.CharField(max_length=250, help_text='Please enter the name of the package')
    image = models.ImageField(upload_to='package_image/', help_text='Please enter the image for the package')
    actual_price = models.IntegerField(help_text='Please enter the actual price of the package')
    discounted_price = models.IntegerField(help_text='Please enter the discounted price of the package')
    ratings = models.IntegerField(help_text='Please enter the rating for the package')
    star_rating = models.DecimalField(max_digits=2, decimal_places=1)

    def __str__(self):
        return self.name


class PackageHighlight(models.Model):
    package = models.ForeignKey(Package, related_name='package_highlights', on_delete=models.CASCADE)
    name = models.CharField(max_length=250, help_text='Please enter the name for the package highlight')
    image = models.ImageField(upload_to='package_highlight/',
                              help_text='Please enter the image for the package highlight')

    def __str__(self):
        return self.name


class Procedure(models.Model):
    package = models.ForeignKey(Package, related_name='procedures', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='procedure_image/', help_text='Please enter the image for the procedure')
    title = models.CharField(max_length=250, help_text='Please enter the title for the procedure')
    description = models.TextField(help_text='Please enter the description for the Procedure')

    def __str__(self):
        return self.title
