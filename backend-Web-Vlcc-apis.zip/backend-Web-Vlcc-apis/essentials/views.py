from rest_framework.views import APIView
from django.shortcuts import get_object_or_404

from .serializers import *
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from rest_framework import generics
from rest_framework import status
from rest_framework import filters
from django.db.models import F, ExpressionWrapper, fields
from django.db.models.functions import ACos, Cos, Sin, Radians, Pi, Sqrt

paginator = PageNumberPagination()

"""
    Essential APIs
"""


class CreateEssentialAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            serializer = EssentialSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            else:
                return Response(serializer.errors)
        except Exception as e:
            return Response({'message': str(e)}, status=400)


class GetEssentialAPIView(APIView):
    def get(self, request, *args, **kwargs):
        try:
            if 'id' in request.GET:
                obj =Essential.objects.filter(id=request.GET['id']).prefetch_related('packages')
                serializer = EssentialPackageSerializer(obj,many=True)
                return Response(serializer.data)
            paginated_queryset = paginator.paginate_queryset(Essential.objects.all(), request)
            serializer = EssentialPackageSerializer(paginated_queryset, many=True)

            return paginator.get_paginated_response(serializer.data)
        except Exception as e:
            return Response({'message': str(e)}, status=400)


"""
    Package APIs
"""


class CreatePackageAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            serializer = PackageSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            else:
                return Response(serializer.errors)
        except Exception as e:
            return Response({'message': str(e)}, status=400)


class GetPackageAPIView(APIView):
    def get(self, request, *args, **kwargs):
        try:
            if 'id' in request.GET:
                obj = Package.objects.get(id=request.GET['id'])
                serializer = EssentialSerializer(obj)
                return Response(serializer.data)
            paginated_queryset = paginator.paginate_queryset(Package.objects.all(), request)
            serializer = PackageSerializer(paginated_queryset, many=True)

            return paginator.get_paginated_response(serializer.data)
        except Exception as e:
            return Response({'message': str(e)}, status=400)
