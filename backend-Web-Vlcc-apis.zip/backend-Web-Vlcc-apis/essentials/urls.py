from .views import *
from django.urls import path

urlpatterns = [


    ### Essential APIs
    path('create-essential/', CreateEssentialAPIView.as_view()),
    path('get-essential/', GetEssentialAPIView.as_view()),


    ### Package APIs
    path('create-package/', CreatePackageAPIView.as_view()),
    path('get-package/', GetPackageAPIView.as_view()),

]
