from rest_framework.views import APIView
from django.shortcuts import get_object_or_404

from .serializers import *
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from rest_framework import generics
from rest_framework import status
from rest_framework import filters
from django.db.models import F, ExpressionWrapper, fields
from django.db.models.functions import ACos, Cos, Sin, Radians, Pi, Sqrt

paginator = PageNumberPagination()

"""
    Concern APIs
"""
class CreateConcernAPI(APIView):
   def post(self, request, *args, **kwargs):
       try:
           serializer = ConcernSerializer(data=request.data)
           if serializer.is_valid():
               serializer.save()
               return Response(serializer.data)
           else:
               return Response(serializer.errors)
       except Exception as e:
           return Response({'message': str(e)},status=400)
class GetConcernAPI(APIView):
   def get(self, request, *args, **kwargs):
       try:
           if('id' in request.GET):
               obj = Concern.objects.get(id=request.GET['id'])
               serializer = ConcernSerializer(obj)
               return Response(serializer.data)
           paginated_queryset = paginator.paginate_queryset(Concern.objects.all(), request)
           serializer = ConcernSerializer(paginated_queryset, many=True)

           return paginator.get_paginated_response(serializer.data)
       except Exception as e:
           return Response({'message': str(e)},status=400)

"""
    Solution APIs
"""

class CreateSolutionAPI(APIView):
   def post(self, request, *args, **kwargs):
       try:
           serializer = SolutionSerializer(data=request.data)
           if serializer.is_valid():
               serializer.save()
               return Response(serializer.data)
           else:
               return Response(serializer.errors)
       except Exception as e:
           return Response({'message': str(e)},status=400)
class GetSolutionAPI(APIView):
   def get(self, request, *args, **kwargs):
       try:
           if('id' in request.GET):
               obj = get_object_or_404(Solution,id=request.GET['id'])
               serializer = SolutionSerializer(obj)

               return Response(serializer.data)
           paginated_queryset = paginator.paginate_queryset(Solution.objects.all(), request)
           serializer = SolutionSerializer(paginated_queryset, many=True)

           return paginator.get_paginated_response(serializer.data)
       except Exception as e:
           return Response({'message': str(e)},status=400)

"""
    Impact Area APIs
"""

class CreateImpactAreaAPI(APIView):
   def post(self, request, *args, **kwargs):
       try:
           serializer = ImpactAreaSerializer(data=request.data)
           if serializer.is_valid():
               serializer.save()
               return Response(serializer.data)
           else:
               return Response(serializer.errors)
       except Exception as e:
           return Response({'message': str(e)},status=400)
class GetImpactAreaAPI(APIView):
   def get(self, request, *args, **kwargs):
       try:
           if('id' in request.GET):
               obj = get_object_or_404(ImpactArea,id=request.GET['id'])
               serializer = GetImpactAreaSerializer(obj)

               return Response(serializer.data)
           paginated_queryset = paginator.paginate_queryset(ImpactArea.objects.all(), request)
           serializer = ImpactAreaSerializer(paginated_queryset, many=True)

           return paginator.get_paginated_response(serializer.data)
       except Exception as e:
           return Response({'message': str(e)},status=400)

"""
    Country APIs
"""

class CreateCountryAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = CountrySerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
class GetCountryAPI(APIView):
   def get(self, request, *args, **kwargs):
       if('id' in request.data.keys()):
           obj = Country.objects.get(id=request.data['id'])
           serializer = CountrySerializer(data=obj)
           return Response(serializer.data)
       paginated_queryset = paginator.paginate_queryset(Country.objects.all(), request)
       serializer = CountrySerializer(paginated_queryset, many=True)

       return paginator.get_paginated_response(serializer.data)

"""
    State APIs
"""

class CreateStateAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = StateSerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
class GetStateAPI(APIView):
   def get(self, request, *args, **kwargs):
       if('id' in request.data.keys()):
           obj = State.objects.get(id=request.data['id'])
           serializer = StateSerializer(data=obj);
       paginated_queryset = paginator.paginate_queryset(State.objects.all(), request)
       serializer = StateSerializer(paginated_queryset, many=True)

       return paginator.get_paginated_response(serializer.data)

"""
    City APIs
"""

class CreateCityAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = CitySerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
class GetCityAPI(APIView):
   def get(self, request, *args, **kwargs):
       if('id' in request.data.keys()):
           obj = City.objects.get(id=request.data['id'])
           serializer = CitySerializer(data=obj);
       paginated_queryset = paginator.paginate_queryset(City.objects.all(), request)
       serializer = CitySerializer(paginated_queryset, many=True)

       return paginator.get_paginated_response(serializer.data)

"""
    Center APIs
"""

class CreateCenterAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = CenterSerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
class GetCenterAPI(APIView):
    def get(self, request, *args, **kwargs):
        if ('id' in request.data.keys()):
            obj = Center.objects.get(id=request.data['id'])
            serializer = CenterSerializer(data=obj)
        paginated_queryset = paginator.paginate_queryset(Center.objects.all(), request)
        serializer = CenterSerializer(paginated_queryset, many=True)

        return paginator.get_paginated_response(serializer.data)

"""
    Search API
"""
class SearchAPIView(generics.ListAPIView):
    serializer_class = None  # Will be set dynamically

    def get(self, request, *args, **kwargs):
        query = self.request.query_params.get('query', '')

        # impact_areas = ImpactArea.objects.filter(name__icontains=query)
        concerns = Concern.objects.filter(headline__icontains=query)
        solutions = Solution.objects.filter(name__icontains=query)

        # impact_area_serializer = ImpactAreaSerializer(impact_areas, many=True)
        concern_serializer = ConcernSearchSerializer(concerns, many=True)
        solution_serializer = SolutionSearchSerializer(solutions, many=True)

        return Response({'concern': concern_serializer.data,'solution':solution_serializer.data}, status=status.HTTP_200_OK)

"""
    Testimonial APIs
"""

class CreateTestimonialAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = CenterSerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
class GetTestimonialAPI(APIView):
    def get(self, request, *args, **kwargs):
        if ('id' in request.data.keys()):
            obj = Testimonial.objects.get(id=request.data['id'])
            serializer = TestimonialSerializer(data=obj)
            return Response(serializer.data)
        paginated_queryset = paginator.paginate_queryset(Testimonial.objects.all(), request)
        serializer = TestimonialSerializer(paginated_queryset, many=True)

        return paginator.get_paginated_response(serializer.data)

"""
    Appointment APIs
"""
class CreateAppointmentAPI(APIView):
   def post(self, request, *args, **kwargs):
       serializer = AppointmentSerializer(data=request.data)
       if serializer.is_valid():
           serializer.save()
           return Response(serializer.data)
       else:
           return Response(serializer.errors)
       
class GetAppointmentAPI(APIView):
    def get(self, request, *args, **kwargs):
        if ('id' in request.data.keys()):
            obj = Appointment.objects.get(id=request.data['id'])
            serializer = AppointmentSerializer(data=obj)
            return Response(serializer.data)
        paginated_queryset = paginator.paginate_queryset(Appointment.objects.all(), request)
        serializer = AppointmentSerializer(paginated_queryset, many=True)

        return paginator.get_paginated_response(serializer.data)

class CenterList(generics.ListAPIView):
    serializer_class = CenterSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['distance']

    def get_queryset(self):
        lat = self.request.query_params.get('lat')
        lon = self.request.query_params.get('lon')

        try:
            lat = float(lat)
            lon = float(lon)
        except ValueError:
            return Center.objects.none()

        # Convert latitude and longitude to radians
        lat_rad = Radians(F('latitude'))
        lon_rad = Radians(F('longitude'))
        target_lat_rad = Radians(lat)
        target_lon_rad = Radians(lon)

        # Calculate the spherical distance
        acos_expr = ACos(
            Cos(target_lat_rad) * Cos(lat_rad) *
            Cos(target_lon_rad - lon_rad) +
            Sin(target_lat_rad) * Sin(lat_rad)
        )
        distance_expr = ExpressionWrapper(
            6371 * acos_expr,
            output_field=fields.FloatField(),
        )

        # Add distance field to the queryset and order by it in descending order
        queryset = Center.objects.annotate(distance=distance_expr).order_by('-distance')

        return queryset


class CenterListByCity(generics.ListAPIView):
    serializer_class = CenterSerializer

    def get_queryset(self):
        city = self.request.query_params.get('city')  # Retrieve the city from the URL parameter
        queryset = Center.objects.filter(city__city=city)
        return queryset