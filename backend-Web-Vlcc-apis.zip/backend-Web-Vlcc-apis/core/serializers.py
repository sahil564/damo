from rest_framework import serializers
from .models import *
class ImpactAreaConcernSerializer(serializers.ModelSerializer):
    class Meta:
        model = Concern
        fields = ['id','headline','concern_thumbnail','thumbnail','main_image']
class ClaimSerializer(serializers.ModelSerializer):
    class Meta:
        model = Claim
        fields = '__all__'

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = '__all__'

class TestimonialImagesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TestimonialImages
        fields = '__all__'

class SolutionBenefitSerializer(serializers.ModelSerializer):
    class Meta:
        model = SolutionBenefit
        fields = '__all__'

class FAQSerializer(serializers.ModelSerializer):

    class Meta:
        model = FAQ
        fields = '__all__'

class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = '__all__'

class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = '__all__'

class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = City
        fields = '__all__'
class CenterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Center
        fields = '__all__'

class CarouselImagesSerializer(serializers.ModelSerializer):
    class Meta:
        model = CarouselImages
        fields = '__all__'

class HighlightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Highlight
        fields = '__all__'


class ImpactAreaSerializer(serializers.ModelSerializer):
    concerns = serializers.PrimaryKeyRelatedField(many=True,read_only=True)
    class Meta:
        model = ImpactArea
        fields = '__all__'

class GetImpactAreaSerializer(serializers.ModelSerializer):
    concerns = ImpactAreaConcernSerializer(many=True, read_only=True)
    class Meta:
        model = ImpactArea
        fields = '__all__'

class VlccMachineSerializer(serializers.ModelSerializer):
    class Meta:
        model = VlccMachine
        fields = '__all__'

class TestimonialSerializer(serializers.ModelSerializer):
    impact_area = ImpactAreaSerializer(source='solution.concern.impact_area')
    testimonial_images = TestimonialImagesSerializer(many=True, read_only=True)
    class Meta:
        model = Testimonial
        fields = '__all__'
class SolutionSerializer(serializers.ModelSerializer):
    claims = ClaimSerializer(many=True,read_only=True)
    testimonials = TestimonialSerializer(many=True,read_only=True)
    # benefits = SolutionBenefitSerializer(many=True,read_only=True)
    # carousel_images = CarouselImagesSerializer(many=True,read_only=True)
    faqs = FAQSerializer(many=True,read_only=True)
    features = HighlightSerializer(many=True,read_only=True)
    impact_area = ImpactAreaSerializer(source='concern.impact_area',read_only=True)
    solution_tags = TagSerializer(many=True, read_only=True)
    vlcc_machine = VlccMachineSerializer(read_only=True)
    class Meta:
        model = Solution
        fields = '__all__'


class ConcernSerializer(serializers.ModelSerializer):
    solutions = SolutionSerializer(many=True,read_only=True)
    concern_tags = TagSerializer(many=True, read_only=True)
    class Meta:
        model = Concern
        fields = '__all__'

class ConcernSearchSerializer(serializers.ModelSerializer):
    concern_tags = TagSerializer(many=True, read_only=True)
    class Meta:
        model = Concern
        fields = ['id','headline','concern_tags','concern_thumbnail']

class SolutionSearchSerializer(serializers.ModelSerializer):
    solution_tags = TagSerializer(many=True, read_only=True)
    class Meta:
        model = Solution
        fields = ['id','name','solution_tags','solution_thumbnail']

class AppointmentSerializer(serializers.ModelSerializer):
    # solution_tags = TagSerializer(many=True, read_only=True)
    class Meta:
        model = Appointment
        fields = '__all__'