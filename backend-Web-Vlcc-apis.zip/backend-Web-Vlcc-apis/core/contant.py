SIGNUP = "http://45.249.109.246/api/api_client_signup.php?request=client_signup"
SIGNIN = "http://45.249.109.246/api/api_client_signin.php?request=login_otp"
AUTH_TOKEN_URL = "http://45.249.109.246/api/api_client_token.php?request=login_token"
APP_URL = "http://45.249.109.246/api/api_book_new_appointment.php?request=client_book_new_appointment"
D_ID='00000000-89ABCDEF-01234567-89ABCD67'
F_ID='e5a91d9f39fa4de254a1e89df00f05b7e248b956'
FILES=[]
HEADERS = {}