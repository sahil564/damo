from django.contrib import admin
from core.models import *

# Register your models here.

admin.site.register(Payment_status)
admin.site.register(Country)
admin.site.register(State)
admin.site.register(City)
admin.site.register(Center)
admin.site.register(Tag)
admin.site.register(VlccMachine)


class ConcernAdminView(admin.ModelAdmin):
    list_display = (
    "id", "thumbnail", "video", "headline", "short_description", "description", "impact_area", "main_image",
    "concern_thumbnail", "concern_tags")

    def concern_tags(self, obj):
        return ", ".join([tag.name for tag in obj.concern_tags.all()])

    concern_tags.short_description = 'Tags'


class SolutionAdminView(admin.ModelAdmin):
    list_display = (
    "id", "concern", "name", "video", "title_carousel", "solution_thumbnail", "solution_small_thumbnail",
    "solution_tags")

    def solution_tags(self, obj):
        return ", ".join([tag.name for tag in obj.solution_tags.all()])

    solution_tags.short_description = 'Tags'


class FAQAdminView(admin.ModelAdmin):
    list_display = ("id", "solution", "question", "answer")


class HighlightsAdminView(admin.ModelAdmin):
    list_display = ("id", "solution", "image", "title")


class ImpactAreaAdminView(admin.ModelAdmin):
    list_display = ("id", "name")


class SolutionBenefitAdminView(admin.ModelAdmin):
    list_display = ("id", "solution", "title", "image")


class ClaimAdminView(admin.ModelAdmin):
    list_display = ("id", "solution", "title", "image")


class TestimonialAdminView(admin.ModelAdmin):
    list_display = ("id", "title", "description", "name_of_person", "solution", "city")


class TestimonialImagesAdminView(admin.ModelAdmin):
    list_display = ("id", "image", "testimonial")


class CarouselImagesAdminView(admin.ModelAdmin):
    list_display = ("id", "solution", "image")


class TestimonialImagesInline(admin.TabularInline):  # or admin.StackedInline
    model = TestimonialImages
    extra = 1


class TestimonialAdmin(admin.ModelAdmin):
    inlines = [TestimonialImagesInline]
    list_display = ('name_of_person', 'title', 'description', 'city', 'display_image')

    def display_image(self, obj):
        images = TestimonialImages.objects.filter(testimonial=obj)
        if images:
            return images[0].image.url
        return 'No Image'

    display_image.short_description = 'Image'


admin.site.register(Concern, ConcernAdminView)
admin.site.register(Solution, SolutionAdminView)
admin.site.register(FAQ, FAQAdminView)
admin.site.register(Highlight, HighlightsAdminView)
admin.site.register(ImpactArea, ImpactAreaAdminView)
admin.site.register(SolutionBenefit, SolutionBenefitAdminView)
admin.site.register(Claim, ClaimAdminView)
admin.site.register(Testimonial, TestimonialAdmin)
admin.site.register(TestimonialImages, TestimonialImagesAdminView)
admin.site.register(CarouselImages, CarouselImagesAdminView)
admin.site.register(Appointment)