from django.db import models
from django.core.exceptions import ValidationError


class VlccMachine(models.Model):
    name = models.CharField(max_length=250, help_text='Please enter the name of the machine')
    image = models.ImageField(upload_to='vlcc_machine_image/', help_text='Please enter the image for the machine')
    description = models.TextField(help_text='Please enter the description for the image')

    def __str__(self):
        return self.name


class ImpactArea(models.Model):
    name = models.CharField(max_length=250, help_text='Enter the name for the impact area')
    image = models.ImageField(upload_to='impact_area/', default=None, null=True)

    def __str__(self):
        return self.name


class Tag(models.Model):
    name = models.CharField(max_length=250, default=None, null=True)

    def __str__(self):
        return self.name


class Concern(models.Model):
    # fields of the model
    concern_thumbnail = models.ImageField(upload_to='concern_second_thumbnails/', default=None, null=True)
    thumbnail = models.ImageField(upload_to='concern_thumbnails/')
    main_image = models.ImageField(upload_to='concern_main_image/', default=None, null=True)
    video = models.FileField(default='Enter value', help_text='Please enter the video')
    headline = models.CharField(max_length=250, help_text='Please enter the headline for the concern')
    short_description = models.TextField(default='Please enter a short description for concern')
    description = models.TextField(default='Please enter the description')
    impact_area = models.ForeignKey(ImpactArea, related_name='concerns', default=None, on_delete=models.CASCADE,
                                    null=True)
    concern_tags = models.ManyToManyField(Tag, related_name='concern_tags', default=None, blank=True)


    def __str__(self):
        return self.headline


class Solution(models.Model):
    concern = models.ForeignKey(Concern, related_name='solutions', on_delete=models.CASCADE)
    solution_code=models.CharField(max_length=100,help_text="please enter solution code",null=True)
    name = models.CharField(max_length=250, help_text='Please enter the name for the solution')
    video = models.FileField(upload_to='solution_video/', help_text='Please submit the video for the solution')
    title_carousel = models.CharField(max_length=200, default="Please enter the title for the carousel")
    solution_thumbnail = models.ImageField(upload_to='solution_thumbnail/',
                                           help_text='Please enter the image for the benefit of the solution',
                                           default=None, null=True)
    solution_small_thumbnail = models.ImageField(upload_to='solution_small_thumbnail/',
                                                 help_text='Please enter the image for the benefit of the solution',
                                                 default=None, null=True)
    solution_tags = models.ManyToManyField(Tag, related_name='solution_tags', default=None, blank=True)
    vlcc_machine = models.OneToOneField(VlccMachine, on_delete=models.CASCADE, default=None, blank=True)

    def __str__(self):
        return self.name


class Country(models.Model):
    country = models.CharField(max_length=100)

    def __str__(self):
        return self.country


class State(models.Model):
    # fields of the model
    country = models.ForeignKey(Country, null=True, on_delete=models.SET_NULL)
    state = models.CharField(max_length=100)

    def __str__(self):
        return self.state


class City(models.Model):
    state = models.ForeignKey(State, null=True, on_delete=models.SET_NULL)
    city = models.CharField(max_length=100)

    def __str__(self):
        return self.city


class Center(models.Model):

    def validate_contact_number(value):
        if (len(value) < 10):
            raise ValidationError("Please enter a valid contact number")

    city = models.ForeignKey(City, null=True, on_delete=models.SET_NULL)
    center_code=models.CharField(max_length=100,help_text="please enter center code",default=None,null=True)
    center_id=models.CharField(max_length=100,help_text="please enter center id",default=None,null=True)
    service_center = models.CharField(max_length=100, help_text='Please enter the name of the center',
                                      verbose_name='Name of the center')
    longitude = models.CharField(max_length=100, help_text='Please enter the longitude of the center', default=None)
    latitude = models.CharField(max_length=100, help_text='Please enter the latitude of the center', default=None)
    address = models.TextField(help_text='Please enter the address of the store', default=None)
    contact = models.CharField(max_length=10, help_text='Please enter the contact number for the center', default=None,
                               validators=[validate_contact_number], verbose_name='contact number')

    def __str__(self):
        return self.service_center


class Date(models.Model):
    date = models.CharField(max_length=100)
    time = models.CharField(max_length=100)


class Payment_status(models.Model):
    User_name = models.CharField(max_length=100)
    Phone_Number = models.CharField(max_length=100)
    status = models.CharField(max_length=100, choices=(("PENDING", 'Pending'), ("DONE", 'Done'),), default="Pending")


class Claim(models.Model):
    solution = models.ForeignKey(Solution, related_name='claims', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='solution_claims/')
    title = models.CharField(max_length=250, help_text='Please enter the title for the Claim')

    def __str__(self):
        return self.title


class Testimonial(models.Model):
    title = models.CharField(max_length=250, help_text='Please enter the title')
    description = models.TextField(help_text='Please enter the description')
    name_of_person = models.CharField(max_length=250, help_text='Please enter the testimonial\'s name')
    solution = models.ForeignKey(Solution, related_name='testimonials', on_delete=models.CASCADE)
    city = models.CharField(max_length=100, help_text='Please enter the city', default='New Delhi')

    def __str__(self):
        return self.name_of_person


class TestimonialImages(models.Model):
    image = models.ImageField(upload_to='testimonial_images/')
    testimonial = models.ForeignKey(Testimonial, related_name='testimonial_images', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id)


class FAQ(models.Model):
    solution = models.ForeignKey(Solution, related_name='faqs', on_delete=models.CASCADE)
    question = models.CharField(max_length=250, null=False, help_text='Please enter the FAQ question')
    answer = models.TextField(null=False, help_text='Please enter the answer for the question')

    def __str__(self):
        return self.question


class Highlight(models.Model):
    solution = models.ForeignKey(Solution, related_name='features', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='solution_features/')
    title = models.CharField(max_length=250)

    def __str__(self):
        return self.title


class CarouselImages(models.Model):
    solution = models.ForeignKey(Solution, on_delete=models.CASCADE, related_name='carousel_images',
                                 help_text='Select the solution for which carousel is to be added')
    image = models.ImageField(upload_to='carousel_images/', help_text='Please enter the image of the carousel')


class SolutionBenefit(models.Model):
    solution = models.ForeignKey(Solution, on_delete=models.CASCADE, related_name='benefits',
                                 help_text='Select the solution for which carousel is to be added')
    title = models.CharField(max_length=250, help_text='Please enter the benefit for the solution')
    image = models.ImageField(upload_to='solution_benefits/',
                              help_text='Please enter the image for the benefit of the solution')

    def __str__(self):
        return self.title


class Appointment(models.Model):
    user_name= models.CharField(max_length=200,help_text='Enter user name',null=True)
    user_phone= models.CharField(max_length=200,help_text='Enter user phone',null=False)
    user_email= models.CharField(max_length=200,help_text='Enter user email',null=True)
    user_gender=models.CharField(max_length=200,help_text="Enter user gender",null=True)
    center = models.ForeignKey(Center, null=True, on_delete=models.SET_NULL)
    service = models.ForeignKey(Solution, related_name='appointment', on_delete=models.CASCADE)
    datetime = models.DateTimeField(db_comment="Date and time when for the appointment")

    def __str__(self) -> str:
        return self.user_name