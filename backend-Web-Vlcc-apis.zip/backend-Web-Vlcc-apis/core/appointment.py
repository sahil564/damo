from django.db.models.signals import post_save, pre_save
import requests
import json
from core.models import *
from core.contant import *
HEADERS={}

def http_method(url,payload):
    response = requests.request("POST", url, headers=HEADERS, data=payload, files=FILES)
    dict=response.json()
    return dict




def center_code(center_name):
    c_code=Center.objects.get(service_center="Delhi GK II").center_code
    return c_code
    

def service_code(service_name):
    s_code=Solution.objects.get(name="Eye liner").solution_code
    return s_code
    




def signup(lead):
    payload = {'client_name': lead.user_name,'client_mobile': lead.user_phone,'client_email': lead.user_email,'device_id': D_ID,'firebase_token':F_ID }
    response = http_method(SIGNUP,payload)
    try:
        return response["ClientSignupInfo"]["OTP"]
    except:
        return 

def signin(lead):
    payload = {'login_mobile': lead.user_phone,'device_id': '00000000-89ABCDEF-01234567-89ABCD67'}
    response = http_method(SIGNIN,payload)
    try:
        print("hello this sigin api")
        return response["LoginInfo"]["OTP"]
        
    except:
        return 


def auth_token(lead,otp):
    payload = {'login_mobile':lead.user_phone,'client_otp': otp,'firebase_token': D_ID}
    response = http_method(AUTH_TOKEN_URL,payload)
    token=response["TokenInfo"]["auth_token"]
    create_appointment(lead,token)
    print("this is auth")
    return token


def create_appointment(lead,auth_token):
    payload = {'auth_token':auth_token ,'device_id': D_ID,'client_mobile':lead.user_phone,'client_emailid':lead.user_email,
    'client_name': lead.user_phone,'client_gender':lead.user_gender,'service_code': service_code(lead.service),'center_code': center_code(lead.center),
    'appointment_date': lead.datetime.date().strftime('%y-%m-%d'),'appointment_time': lead.datetime.time().strftime("%H:%M:%S"),'appointment_comment': 'ok','appointment_type': 'General','txn_info': ''}
    response = http_method(APP_URL,payload)
    print("this apointment create")
    return response


def appointment_lead(lead_instance):
    otp=signin(lead_instance)
    if otp:
        auth_token(lead_instance,otp)
    else:
        new_user_otp=signup(lead_instance)
        auth_token(lead_instance,new_user_otp)
    
