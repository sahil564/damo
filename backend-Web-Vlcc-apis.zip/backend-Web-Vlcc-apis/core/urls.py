from .views import *
from django.urls import path

urlpatterns = [

    ###    Solution APIs
    path('create-solution/', CreateSolutionAPI.as_view()),
    path('get-solution/', GetSolutionAPI.as_view()),

    ###    Impact Area APIs
    path('create-impact-area/', CreateImpactAreaAPI.as_view()),
    path('get-impact-area/', GetImpactAreaAPI.as_view()),

    ###    Concern APIs
    path('create-concern/', CreateConcernAPI.as_view()),
    path('get-concern/', GetConcernAPI.as_view()),

    ###    Country APIs
    path('create-country/', CreateCountryAPI.as_view()),
    path('get-country/', GetCountryAPI.as_view()),

    ###    State APIs
    path('create-state/', CreateStateAPI.as_view()),
    path('get-state/', GetStateAPI.as_view()),

    ###    City APIs
    path('create-city/', CreateCityAPI.as_view()),
    path('get-city/', GetCityAPI.as_view()),

    ###    Center APIs
    path('create-center/', CreateCenterAPI.as_view()),
    path('get-center/', GetCenterAPI.as_view()),

    ###    Search API
    path('search/',SearchAPIView.as_view()),

    ##     Testimonials API
    path('create-testimonial/', CreateTestimonialAPI.as_view()),
    path('get-testimonials/', GetTestimonialAPI.as_view()),

    ###    Apppointment API
    path('create-appointment/', CreateAppointmentAPI.as_view()),
    path('get-appointment/', GetAppointmentAPI.as_view()),

    ###    Store locator API
    path('centers/', CenterList.as_view(), name='center-list'),
    path('city-centers/', CenterListByCity.as_view(), name='center-list-by-city'),

]
