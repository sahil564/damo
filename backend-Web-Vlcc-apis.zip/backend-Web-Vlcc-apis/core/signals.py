from django.db import models
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from core.models import *
from .appointment import appointment_lead


@receiver(post_save, sender=Appointment)
def appointment_saved(sender, instance, created, **kwargs):
    if created:
        # This code will be executed when a new Lead object is created and saved to the database.
        # You can perform any additional actions or tasks here.
        # sahil: import the function to call from services.py file
        appointment_lead(lead_instance=instance)
    else:
        # This code will be executed when an existing Lead object is updated and saved to the database.
        # You can perform any additional actions or tasks here.
        pass